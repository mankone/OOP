-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 04, 2014 at 02:27 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `persons`
--

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE IF NOT EXISTS `records` (
  `Fname` varchar(30) NOT NULL,
  `Sname` varchar(30) NOT NULL,
  `Farmerno` int(255) NOT NULL AUTO_INCREMENT,
  `Noofbags` int(255) NOT NULL,
  PRIMARY KEY (`Farmerno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`Fname`, `Sname`, `Farmerno`, `Noofbags`) VALUES
('joshua', 'mankone', 1, 0),
('Michael', 'Joseph', 2, 0),
('joshua', 'mankone', 3, 0),
('Michael', ' Mwangi', 4, 0),
('Michael', ' Mwangi', 5, 0),
('Michael', ' Mwangi', 6, 0),
('Michael', ' Mwangi', 7, 0),
('Michael', ' Mwangi', 8, 2),
('Michael', ' Mwangi', 9, 2);
